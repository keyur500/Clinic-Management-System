﻿namespace Hospital_Management_System
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AddPatientBtn = new System.Windows.Forms.Button();
            this.AddDiagnoseDataBtn = new System.Windows.Forms.Button();
            this.FullDetailsBtn = new System.Windows.Forms.Button();
            this.ProjectDetailsBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.sign1 = new System.Windows.Forms.Label();
            this.sign2 = new System.Windows.Forms.Label();
            this.sign3 = new System.Windows.Forms.Label();
            this.sign4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.nameTb = new System.Windows.Forms.TextBox();
            this.AddressTb = new System.Windows.Forms.TextBox();
            this.phoneTb = new System.Windows.Forms.TextBox();
            this.ageTb = new System.Windows.Forms.TextBox();
            this.bloodGroupTb = new System.Windows.Forms.TextBox();
            this.patientIdTb = new System.Windows.Forms.TextBox();
            this.genderCb = new System.Windows.Forms.ComboBox();
            this.addSaveBtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.prevDiseaseTb = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.addDiagnosePanel = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pidTb = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.symptomsTb = new System.Windows.Forms.TextBox();
            this.diagnosisTb = new System.Windows.Forms.TextBox();
            this.prescriptionTb = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.roomNoCb = new System.Windows.Forms.ComboBox();
            this.drTb = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.detailsPanel = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.fullDetailsGridView = new System.Windows.Forms.DataGridView();
            this.panelProjectDetails = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelMain.SuspendLayout();
            this.addDiagnosePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.detailsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fullDetailsGridView)).BeginInit();
            this.panelProjectDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(499, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(696, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Acme Clinic Management System";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.sign4);
            this.panel1.Controls.Add(this.sign3);
            this.panel1.Controls.Add(this.sign2);
            this.panel1.Controls.Add(this.sign1);
            this.panel1.Controls.Add(this.ProjectDetailsBtn);
            this.panel1.Controls.Add(this.FullDetailsBtn);
            this.panel1.Controls.Add(this.AddDiagnoseDataBtn);
            this.panel1.Controls.Add(this.AddPatientBtn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1725, 152);
            this.panel1.TabIndex = 1;
            // 
            // AddPatientBtn
            // 
            this.AddPatientBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddPatientBtn.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.AddPatientBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddPatientBtn.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.AddPatientBtn.Location = new System.Drawing.Point(130, 83);
            this.AddPatientBtn.Name = "AddPatientBtn";
            this.AddPatientBtn.Size = new System.Drawing.Size(237, 54);
            this.AddPatientBtn.TabIndex = 2;
            this.AddPatientBtn.Text = "Add New Patient";
            this.AddPatientBtn.UseVisualStyleBackColor = false;
            this.AddPatientBtn.Click += new System.EventHandler(this.AddPatientBtn_Click);
            // 
            // AddDiagnoseDataBtn
            // 
            this.AddDiagnoseDataBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddDiagnoseDataBtn.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.AddDiagnoseDataBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddDiagnoseDataBtn.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.AddDiagnoseDataBtn.Location = new System.Drawing.Point(481, 83);
            this.AddDiagnoseDataBtn.Name = "AddDiagnoseDataBtn";
            this.AddDiagnoseDataBtn.Size = new System.Drawing.Size(297, 54);
            this.AddDiagnoseDataBtn.TabIndex = 3;
            this.AddDiagnoseDataBtn.Text = "Add Diagnose Data";
            this.AddDiagnoseDataBtn.UseVisualStyleBackColor = false;
            this.AddDiagnoseDataBtn.Click += new System.EventHandler(this.AddDiagnoseDataBtn_Click);
            // 
            // FullDetailsBtn
            // 
            this.FullDetailsBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FullDetailsBtn.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.FullDetailsBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FullDetailsBtn.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.FullDetailsBtn.Location = new System.Drawing.Point(899, 83);
            this.FullDetailsBtn.Name = "FullDetailsBtn";
            this.FullDetailsBtn.Size = new System.Drawing.Size(296, 54);
            this.FullDetailsBtn.TabIndex = 4;
            this.FullDetailsBtn.Text = "Full Details Of Patient";
            this.FullDetailsBtn.UseVisualStyleBackColor = false;
            this.FullDetailsBtn.Click += new System.EventHandler(this.FullDetailsBtn_Click);
            // 
            // ProjectDetailsBtn
            // 
            this.ProjectDetailsBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ProjectDetailsBtn.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.ProjectDetailsBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProjectDetailsBtn.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.ProjectDetailsBtn.Location = new System.Drawing.Point(1343, 83);
            this.ProjectDetailsBtn.Name = "ProjectDetailsBtn";
            this.ProjectDetailsBtn.Size = new System.Drawing.Size(237, 54);
            this.ProjectDetailsBtn.TabIndex = 5;
            this.ProjectDetailsBtn.Text = "Project Details";
            this.ProjectDetailsBtn.UseVisualStyleBackColor = false;
            this.ProjectDetailsBtn.Click += new System.EventHandler(this.ProjectDetailsBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox1.Location = new System.Drawing.Point(12, 167);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1725, 654);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // sign1
            // 
            this.sign1.AutoSize = true;
            this.sign1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sign1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.sign1.Location = new System.Drawing.Point(85, 94);
            this.sign1.Name = "sign1";
            this.sign1.Size = new System.Drawing.Size(39, 29);
            this.sign1.TabIndex = 3;
            this.sign1.Text = "🔴";
            this.sign1.Click += new System.EventHandler(this.sign1_Click);
            // 
            // sign2
            // 
            this.sign2.AutoSize = true;
            this.sign2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sign2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.sign2.Location = new System.Drawing.Point(436, 94);
            this.sign2.Name = "sign2";
            this.sign2.Size = new System.Drawing.Size(39, 29);
            this.sign2.TabIndex = 6;
            this.sign2.Text = "🔴";
            // 
            // sign3
            // 
            this.sign3.AutoSize = true;
            this.sign3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sign3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.sign3.Location = new System.Drawing.Point(854, 94);
            this.sign3.Name = "sign3";
            this.sign3.Size = new System.Drawing.Size(39, 29);
            this.sign3.TabIndex = 7;
            this.sign3.Text = "🔴";
            // 
            // sign4
            // 
            this.sign4.AutoSize = true;
            this.sign4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sign4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.sign4.Location = new System.Drawing.Point(1298, 94);
            this.sign4.Name = "sign4";
            this.sign4.Size = new System.Drawing.Size(39, 29);
            this.sign4.TabIndex = 8;
            this.sign4.Text = "🔴";
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1637, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 43);
            this.button1.TabIndex = 9;
            this.button1.Text = "EXIT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.prevDiseaseTb);
            this.panelMain.Controls.Add(this.label10);
            this.panelMain.Controls.Add(this.label9);
            this.panelMain.Controls.Add(this.addSaveBtn);
            this.panelMain.Controls.Add(this.genderCb);
            this.panelMain.Controls.Add(this.patientIdTb);
            this.panelMain.Controls.Add(this.bloodGroupTb);
            this.panelMain.Controls.Add(this.ageTb);
            this.panelMain.Controls.Add(this.phoneTb);
            this.panelMain.Controls.Add(this.AddressTb);
            this.panelMain.Controls.Add(this.nameTb);
            this.panelMain.Controls.Add(this.label8);
            this.panelMain.Controls.Add(this.label7);
            this.panelMain.Controls.Add(this.label6);
            this.panelMain.Controls.Add(this.label5);
            this.panelMain.Controls.Add(this.label4);
            this.panelMain.Controls.Add(this.label3);
            this.panelMain.Controls.Add(this.label2);
            this.panelMain.Location = new System.Drawing.Point(12, 167);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1725, 654);
            this.panelMain.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(536, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(536, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 26);
            this.label3.TabIndex = 5;
            this.label3.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(536, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 26);
            this.label4.TabIndex = 6;
            this.label4.Text = "Phone";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(536, 282);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 26);
            this.label5.TabIndex = 7;
            this.label5.Text = "Age";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(536, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 26);
            this.label6.TabIndex = 8;
            this.label6.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(536, 416);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 26);
            this.label7.TabIndex = 9;
            this.label7.Text = "Blood Group";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(536, 543);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 26);
            this.label8.TabIndex = 10;
            this.label8.Text = "Patient Id";
            // 
            // nameTb
            // 
            this.nameTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTb.Location = new System.Drawing.Point(731, 48);
            this.nameTb.Name = "nameTb";
            this.nameTb.Size = new System.Drawing.Size(426, 35);
            this.nameTb.TabIndex = 11;
            // 
            // AddressTb
            // 
            this.AddressTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressTb.Location = new System.Drawing.Point(731, 124);
            this.AddressTb.Name = "AddressTb";
            this.AddressTb.Size = new System.Drawing.Size(426, 35);
            this.AddressTb.TabIndex = 12;
            // 
            // phoneTb
            // 
            this.phoneTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneTb.Location = new System.Drawing.Point(731, 200);
            this.phoneTb.Name = "phoneTb";
            this.phoneTb.Size = new System.Drawing.Size(426, 35);
            this.phoneTb.TabIndex = 13;
            // 
            // ageTb
            // 
            this.ageTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageTb.Location = new System.Drawing.Point(731, 274);
            this.ageTb.Name = "ageTb";
            this.ageTb.Size = new System.Drawing.Size(426, 35);
            this.ageTb.TabIndex = 14;
            // 
            // bloodGroupTb
            // 
            this.bloodGroupTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodGroupTb.Location = new System.Drawing.Point(731, 408);
            this.bloodGroupTb.Name = "bloodGroupTb";
            this.bloodGroupTb.Size = new System.Drawing.Size(426, 35);
            this.bloodGroupTb.TabIndex = 16;
            // 
            // patientIdTb
            // 
            this.patientIdTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientIdTb.Location = new System.Drawing.Point(731, 535);
            this.patientIdTb.Name = "patientIdTb";
            this.patientIdTb.Size = new System.Drawing.Size(426, 35);
            this.patientIdTb.TabIndex = 17;
            // 
            // genderCb
            // 
            this.genderCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderCb.FormattingEnabled = true;
            this.genderCb.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.genderCb.Location = new System.Drawing.Point(731, 340);
            this.genderCb.Name = "genderCb";
            this.genderCb.Size = new System.Drawing.Size(426, 37);
            this.genderCb.TabIndex = 18;
            // 
            // addSaveBtn
            // 
            this.addSaveBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.addSaveBtn.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.addSaveBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addSaveBtn.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.addSaveBtn.Location = new System.Drawing.Point(811, 597);
            this.addSaveBtn.Name = "addSaveBtn";
            this.addSaveBtn.Size = new System.Drawing.Size(135, 54);
            this.addSaveBtn.TabIndex = 10;
            this.addSaveBtn.Text = "Save";
            this.addSaveBtn.UseVisualStyleBackColor = false;
            this.addSaveBtn.Click += new System.EventHandler(this.addSaveBtn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(117, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(219, 231);
            this.label9.TabIndex = 19;
            this.label9.Text = "Add \r\nPatient\r\nRecord";
            // 
            // prevDiseaseTb
            // 
            this.prevDiseaseTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prevDiseaseTb.Location = new System.Drawing.Point(731, 472);
            this.prevDiseaseTb.Name = "prevDiseaseTb";
            this.prevDiseaseTb.Size = new System.Drawing.Size(426, 35);
            this.prevDiseaseTb.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(536, 480);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(182, 26);
            this.label10.TabIndex = 20;
            this.label10.Text = "Previous Disease";
            // 
            // addDiagnosePanel
            // 
            this.addDiagnosePanel.Controls.Add(this.button2);
            this.addDiagnosePanel.Controls.Add(this.drTb);
            this.addDiagnosePanel.Controls.Add(this.roomNoCb);
            this.addDiagnosePanel.Controls.Add(this.label17);
            this.addDiagnosePanel.Controls.Add(this.label16);
            this.addDiagnosePanel.Controls.Add(this.prescriptionTb);
            this.addDiagnosePanel.Controls.Add(this.diagnosisTb);
            this.addDiagnosePanel.Controls.Add(this.symptomsTb);
            this.addDiagnosePanel.Controls.Add(this.label15);
            this.addDiagnosePanel.Controls.Add(this.label14);
            this.addDiagnosePanel.Controls.Add(this.label13);
            this.addDiagnosePanel.Controls.Add(this.dataGridView1);
            this.addDiagnosePanel.Controls.Add(this.pidTb);
            this.addDiagnosePanel.Controls.Add(this.label12);
            this.addDiagnosePanel.Controls.Add(this.label11);
            this.addDiagnosePanel.Location = new System.Drawing.Point(12, 167);
            this.addDiagnosePanel.Name = "addDiagnosePanel";
            this.addDiagnosePanel.Size = new System.Drawing.Size(1725, 654);
            this.addDiagnosePanel.TabIndex = 10;
            this.addDiagnosePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.addDiagnosePanel_Paint);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(38, 396);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(437, 126);
            this.label11.TabIndex = 0;
            this.label11.Text = "Add Patient \r\nDiagnose Details\r\n";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(93, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(119, 29);
            this.label12.TabIndex = 1;
            this.label12.Text = "Patient Id ";
            // 
            // pidTb
            // 
            this.pidTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pidTb.Location = new System.Drawing.Point(218, 133);
            this.pidTb.Name = "pidTb";
            this.pidTb.Size = new System.Drawing.Size(238, 35);
            this.pidTb.TabIndex = 2;
            this.pidTb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(532, 107);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1176, 99);
            this.dataGridView1.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(561, 236);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(126, 29);
            this.label13.TabIndex = 4;
            this.label13.Text = "Symptoms";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(561, 368);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(200, 29);
            this.label14.TabIndex = 5;
            this.label14.Text = "Diagnosis Details";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(561, 503);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(247, 29);
            this.label15.TabIndex = 6;
            this.label15.Text = "Medicine Prescription";
            // 
            // symptomsTb
            // 
            this.symptomsTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.symptomsTb.Location = new System.Drawing.Point(566, 277);
            this.symptomsTb.Multiline = true;
            this.symptomsTb.Name = "symptomsTb";
            this.symptomsTb.Size = new System.Drawing.Size(358, 79);
            this.symptomsTb.TabIndex = 7;
            // 
            // diagnosisTb
            // 
            this.diagnosisTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diagnosisTb.Location = new System.Drawing.Point(566, 411);
            this.diagnosisTb.Multiline = true;
            this.diagnosisTb.Name = "diagnosisTb";
            this.diagnosisTb.Size = new System.Drawing.Size(358, 79);
            this.diagnosisTb.TabIndex = 8;
            // 
            // prescriptionTb
            // 
            this.prescriptionTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prescriptionTb.Location = new System.Drawing.Point(566, 552);
            this.prescriptionTb.Multiline = true;
            this.prescriptionTb.Name = "prescriptionTb";
            this.prescriptionTb.Size = new System.Drawing.Size(358, 79);
            this.prescriptionTb.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1149, 236);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(171, 29);
            this.label16.TabIndex = 10;
            this.label16.Text = "Room Number";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1149, 408);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(273, 29);
            this.label17.TabIndex = 11;
            this.label17.Text = "Diagnose By (Dr. Name)";
            // 
            // roomNoCb
            // 
            this.roomNoCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomNoCb.FormattingEnabled = true;
            this.roomNoCb.Items.AddRange(new object[] {
            "A103",
            "B224",
            "E321"});
            this.roomNoCb.Location = new System.Drawing.Point(1154, 284);
            this.roomNoCb.Name = "roomNoCb";
            this.roomNoCb.Size = new System.Drawing.Size(183, 37);
            this.roomNoCb.TabIndex = 12;
            // 
            // drTb
            // 
            this.drTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drTb.Location = new System.Drawing.Point(1154, 453);
            this.drTb.Multiline = true;
            this.drTb.Name = "drTb";
            this.drTb.Size = new System.Drawing.Size(358, 79);
            this.drTb.TabIndex = 13;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Location = new System.Drawing.Point(1266, 577);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 54);
            this.button2.TabIndex = 10;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // detailsPanel
            // 
            this.detailsPanel.Controls.Add(this.fullDetailsGridView);
            this.detailsPanel.Controls.Add(this.label18);
            this.detailsPanel.Location = new System.Drawing.Point(12, 167);
            this.detailsPanel.Name = "detailsPanel";
            this.detailsPanel.Size = new System.Drawing.Size(1725, 654);
            this.detailsPanel.TabIndex = 14;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(445, 52);
            this.label18.TabIndex = 0;
            this.label18.Text = "Full Details Of Patient";
            // 
            // fullDetailsGridView
            // 
            this.fullDetailsGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.fullDetailsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.fullDetailsGridView.Location = new System.Drawing.Point(1, 85);
            this.fullDetailsGridView.Name = "fullDetailsGridView";
            this.fullDetailsGridView.RowHeadersWidth = 62;
            this.fullDetailsGridView.RowTemplate.Height = 28;
            this.fullDetailsGridView.Size = new System.Drawing.Size(1721, 566);
            this.fullDetailsGridView.TabIndex = 1;
            // 
            // panelProjectDetails
            // 
            this.panelProjectDetails.Controls.Add(this.label20);
            this.panelProjectDetails.Controls.Add(this.label19);
            this.panelProjectDetails.Location = new System.Drawing.Point(12, 167);
            this.panelProjectDetails.Name = "panelProjectDetails";
            this.panelProjectDetails.Size = new System.Drawing.Size(1725, 654);
            this.panelProjectDetails.TabIndex = 15;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Candara Light", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(723, 36);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(237, 46);
            this.label19.TabIndex = 0;
            this.label19.Text = "About Project";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Candara Light", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(342, 133);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(1105, 322);
            this.label20.TabIndex = 1;
            this.label20.Text = resources.GetString("label20.Text");
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1749, 944);
            this.Controls.Add(this.panelProjectDetails);
            this.Controls.Add(this.detailsPanel);
            this.Controls.Add(this.addDiagnosePanel);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "dashboard";
            this.Text = "dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.dashboard_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.addDiagnosePanel.ResumeLayout(false);
            this.addDiagnosePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.detailsPanel.ResumeLayout(false);
            this.detailsPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fullDetailsGridView)).EndInit();
            this.panelProjectDetails.ResumeLayout(false);
            this.panelProjectDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ProjectDetailsBtn;
        private System.Windows.Forms.Button FullDetailsBtn;
        private System.Windows.Forms.Button AddDiagnoseDataBtn;
        private System.Windows.Forms.Button AddPatientBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label sign4;
        private System.Windows.Forms.Label sign3;
        private System.Windows.Forms.Label sign2;
        private System.Windows.Forms.Label sign1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.ComboBox genderCb;
        private System.Windows.Forms.TextBox patientIdTb;
        private System.Windows.Forms.TextBox bloodGroupTb;
        private System.Windows.Forms.TextBox ageTb;
        private System.Windows.Forms.TextBox phoneTb;
        private System.Windows.Forms.TextBox AddressTb;
        private System.Windows.Forms.TextBox nameTb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button addSaveBtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox prevDiseaseTb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel addDiagnosePanel;
        private System.Windows.Forms.TextBox drTb;
        private System.Windows.Forms.ComboBox roomNoCb;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox prescriptionTb;
        private System.Windows.Forms.TextBox diagnosisTb;
        private System.Windows.Forms.TextBox symptomsTb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox pidTb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel detailsPanel;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridView fullDetailsGridView;
        private System.Windows.Forms.Panel panelProjectDetails;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
    }
}