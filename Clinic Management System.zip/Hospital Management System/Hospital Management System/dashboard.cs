﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class dashboard : Form
    {

        string Db_connection_string = "data source = DESKTOP-OGTDIGP\\SQLEXPRESS;database = clinicDb; integrated security=True";
        public dashboard()
        {
            InitializeComponent();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
            // visibilty of the panel is disable on the screen during form load  
            panelMain.Visible = false;
            addDiagnosePanel.Visible = false;
            detailsPanel.Visible = false;
            panelProjectDetails.Visible = true;
        }

        private void AddPatientBtn_Click(object sender, EventArgs e)
        {
            sign1.ForeColor = System.Drawing.Color.Green;
            // Changing the color of the other label to black
            sign2.ForeColor = System.Drawing.Color.Black;
            sign3.ForeColor = System.Drawing.Color.Black;
            sign4.ForeColor = System.Drawing.Color.Black;

            panelProjectDetails.Visible = false;
            addDiagnosePanel.Visible = false;
            detailsPanel.Visible = false;
            panelMain.Visible = true;
            
            //panelMain.Visible = true;
        }

        private void AddDiagnoseDataBtn_Click(object sender, EventArgs e)
        {
            sign2.ForeColor = System.Drawing.Color.Green;
            // Changing the color of the other label to black
            sign1.ForeColor = System.Drawing.Color.Black;
            sign3.ForeColor = System.Drawing.Color.Black;
            sign4.ForeColor = System.Drawing.Color.Black;
            panelProjectDetails.Visible = false;
            panelMain.Visible = false;
            detailsPanel.Visible = false;
            addDiagnosePanel.Visible = true;
        }

        private void FullDetailsBtn_Click(object sender, EventArgs e)
        {
            sign3.ForeColor = System.Drawing.Color.Green;
            // Changing the color of the other label to black
            sign1.ForeColor = System.Drawing.Color.Black;
            sign2.ForeColor = System.Drawing.Color.Black;
            sign4.ForeColor = System.Drawing.Color.Black;

            panelMain.Visible = false;
            detailsPanel.Visible = false;
            panelProjectDetails.Visible = false;
            detailsPanel.Visible = true;

            try
            {
                // ** Connecting to sql for showing the data in gridview 

                SqlConnection con = new SqlConnection();
                con.ConnectionString = Db_connection_string;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                // showing the combination of both the table 
                cmd.CommandText = "SELECT  * FROM add_patient INNER JOIN patient_more ON add_patient.pid = patient_more.pid;";

                // to store the data which is coming from sql 
                SqlDataAdapter Da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                Da.Fill(ds);

                fullDetailsGridView.DataSource = ds.Tables[0];
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            
        }

        private void ProjectDetailsBtn_Click(object sender, EventArgs e)
        {
            sign4.ForeColor = System.Drawing.Color.Green;
            // Changing the color of the other label to black
            sign1.ForeColor = System.Drawing.Color.Black;
            sign3.ForeColor = System.Drawing.Color.Black;
            sign2.ForeColor = System.Drawing.Color.Black;

            addDiagnosePanel.Visible = false;
            detailsPanel.Visible = false;
            panelMain.Visible = false;
            panelProjectDetails.Visible = true;
        }

        private void sign1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addSaveBtn_Click(object sender, EventArgs e)
        {
            int isEmpty = 0;
            try
            {
               

                if (nameTb.Text == "" || AddressTb.Text == "" || phoneTb.Text == "" || ageTb.Text == "" || genderCb.Text == "" || bloodGroupTb.Text == "") 
                { isEmpty = 1;
                    if (isEmpty == 1)
                    {
                        MessageBox.Show("Please Enter all text field Data");
                    }
                }

 
                else
                {
                    string name = nameTb.Text;
                    string address = AddressTb.Text;
                    string phone = phoneTb.Text;
                    int age = Convert.ToInt32(ageTb.Text);
                    string gender = genderCb.Text;
                    string blood = bloodGroupTb.Text;
                    string previousDisease = prevDiseaseTb.Text;
                    int pid = Convert.ToInt32(patientIdTb.Text);

                    // Creating a sql connection 
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = Db_connection_string;
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = "insert into add_patient values ('" + name + "','" + address + "','" + phone + "','" + age + "','" + gender + "','" + blood + "','" + previousDisease + "','" + pid + "');";

                    SqlDataAdapter Da = new SqlDataAdapter(cmd);
                    DataSet Ds = new DataSet();
                    Da.Fill(Ds);
                }
            }
            catch (Exception error)
            {
                string result = error.Message;
                MessageBox.Show(result);
            }

            // Once its done then clear textbox
            foreach (Control c in panelMain.Controls)
            {
                if (c is TextBox)
                {
                    TextBox t = (TextBox)c;
                    t.Text = "";
                }
                else if (c is ComboBox)
                {
                    ComboBox cb = (ComboBox)c;
                    cb.SelectedIndex = -1;
                }
                else if (c is RadioButton)
                {
                    RadioButton rb = (RadioButton)c;
                    rb.Checked = false;
                }
                else if (c is CheckBox)
                {
                    CheckBox cb = (CheckBox)c;
                    cb.Checked = false;
                }
            }
            if(isEmpty == 0)
            MessageBox.Show("Patient " + nameTb.Text + " added");
        }

        private void addDiagnosePanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (pidTb.Text != "")
            {
                int pid = Convert.ToInt32(pidTb.Text);
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Db_connection_string;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "select * from add_patient where pid = " + pidTb.Text + ";";

                // to store the data which is coming from sql 
                SqlDataAdapter Da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                Da.Fill(ds);

                dataGridView1.DataSource = ds.Tables[0];
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int pid = Convert.ToInt32(pidTb.Text);
                string symptoms = symptomsTb.Text;
                string diagnosis = diagnosisTb.Text;
                string prescription = prescriptionTb.Text;
                string roomno = roomNoCb.Text;
                string doctorname = drTb.Text;

                SqlConnection con = new SqlConnection();
                con.ConnectionString = Db_connection_string;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "insert into patient_more values('" + pid + "','" + symptoms + "','" + diagnosis + "','" + prescription + "','" + roomno + "','" + doctorname + "');";

                SqlDataAdapter Da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                Da.Fill(ds);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

            pidTb.Text = "";
            // Once its done then clear textbox
            

                MessageBox.Show("Patient Daignosis Details added");


            
        }
    }
}
