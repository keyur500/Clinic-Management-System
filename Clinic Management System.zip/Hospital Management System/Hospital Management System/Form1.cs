﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            string username = UnameTb.Text;
            string password = paswdTb.Text;

            if (username == "admin" && password == "root")
            {
                MessageBox.Show("LogIn Successfull");
                
                // hide the current form 
                this.Hide();
                dashboard dashbObj = new dashboard();
                dashbObj.Show();
            }
            else
            {
                MessageBox.Show("Invalid Credentials");
            }
        }
    }
}
